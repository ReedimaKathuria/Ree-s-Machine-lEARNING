# MACHINE-LEARNING-ALL-FILES-BY-CHANDAN-KUMAR-
this is the collection of the files that were being taught by mrs ranjana mam in our machine learning lab 


<img width="736" height="920" alt="Ai Creativity" src="https://github.com/user-attachments/assets/3cc5fb21-8de3-4685-9ae2-a55f677a3f07" />


